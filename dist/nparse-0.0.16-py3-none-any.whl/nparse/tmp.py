def tmp(a: int) -> int:
    if (a == 0):
        return 1
    else:
        return 0
